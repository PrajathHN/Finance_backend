from django.apps import AppConfig


class FinanceDashboardBackendAppConfig(AppConfig):
    name = 'core'
