from rest_framework.routers import DefaultRouter
from .views import UserViewSet, FinancialRecordViewSet

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'records', FinancialRecordViewSet)

urlpatterns = router.urls